export const story = [
    {
      image: "https://images.pexels.com/photos/380782/pexels-photo-380782.jpeg?auto=compress&cs=tinysrgb&w=600",
      duration: 2000,
    },
    {
      image: "https://images.pexels.com/photos/13009437/pexels-photo-13009437.jpeg?auto=compress&cs=tinysrgb&w=600",
      duration: 2000,
    },
  
    {
      image: "https://images.pexels.com/photos/51396/pocket-watches-time-of-time-watches-51396.jpeg?auto=compress&cs=tinysrgb&w=600",
      duration: 2000,
    },
    {
      image: "https://images.pexels.com/photos/1563643/pexels-photo-1563643.jpeg?auto=compress&cs=tinysrgb&w=600",
      duration: 2000,
    },
  ];
  