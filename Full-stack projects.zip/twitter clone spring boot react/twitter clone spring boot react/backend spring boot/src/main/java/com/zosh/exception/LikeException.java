package com.zosh.exception;

public class LikeException extends Exception {

	public LikeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
