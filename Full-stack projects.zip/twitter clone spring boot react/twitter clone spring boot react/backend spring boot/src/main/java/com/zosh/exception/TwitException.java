package com.zosh.exception;

public class TwitException extends Exception {
	
	public TwitException(String message) {
		super(message);
	}

}
